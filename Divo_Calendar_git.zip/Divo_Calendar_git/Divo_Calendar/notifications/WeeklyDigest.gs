// Add this file to an Apps Script project bound to the Google Sheet containing the catalogue.
const DIGEST_ZONE = 'Asia/Kolkata';

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Divo notifications')
    .addItem('Preview next 7 days', 'previewDigest_')
    .addItem('Enable weekly email', 'enableDigest_')
    .addItem('Stop weekly email', 'stopDigest_').addToUi();
}

function digestRows_(sheet) {
  if (!sheet || !sheet.getLastRow()) throw Error('Select the tab containing your exported calendar.');
  const [headers,...values] = sheet.getDataRange().getValues();
  for (const field of ['title','type','date','language']) {
    if (!headers.includes(field)) throw Error('The selected tab needs a '+field+' column. Import Divo_Import.csv first.');
  }
  const zone = sheet.getParent().getSpreadsheetTimeZone();
  return values.map(row => {
    const get = key => row[headers.indexOf(key)];
    const raw = get('syncedDate') || get('wikidataDate') || get('date');
    const date = raw instanceof Date ? Utilities.formatDate(raw,zone,'yyyy-MM-dd') : String(raw||'').trim();
    return {title:String(get('title')||'').trim(),language:String(get('language')||'').trim(),type:get('type'),date};
  });
}

function buildDigest_(rows, start) {
  const startDate = new Date(start+'T00:00:00Z');
  const sections = [];
  let count = 0;
  let end = start;
  for (let offset=0;offset<7;offset++) {
    const day = new Date(startDate.getTime()+offset*86400000);
    end = day.toISOString().slice(0,10);
    const lines = rows.filter(row=>row.title && ['birth','film','music'].includes(row.type) &&
      /^\d{4}-\d{2}-\d{2}$/.test(row.date) && row.date<=end && row.date.slice(5)===end.slice(5))
      .sort((a,b)=>a.title.localeCompare(b.title)||a.language.localeCompare(b.language))
      .map(row=>{
        const years = Number(end.slice(0,4))-Number(row.date.slice(0,4));
        const label = row.type==='birth'?'Birthday':row.type==='film'?'Film release':'Music release';
        return '• '+row.title+' — '+label+' · '+row.language+' · '+row.date+
          (row.type!=='birth' && years>0?' ('+years+'-year anniversary)':'');
      });
    if (lines.length) sections.push(Utilities.formatDate(day,'UTC','EEEE, d MMMM')+'\n'+lines.join('\n'));
    count += lines.length;
  }
  return {subject:'Divo calendar | '+start+' to '+end,
    body:count+' upcoming calendar '+(count===1?'event':'events')+'\n\n'+
      (sections.join('\n\n')||'No birthdays or releases are listed for the next seven days.')};
}

function digestToday_() {
  return Utilities.formatDate(new Date(), DIGEST_ZONE, 'yyyy-MM-dd');
}

function previewDigest_() {
  const digest=buildDigest_(digestRows_(SpreadsheetApp.getActiveSheet()),digestToday_());
  SpreadsheetApp.getUi().alert(digest.subject,digest.body,SpreadsheetApp.getUi().ButtonSet.OK);
}

function enableDigest_() {
  const ss=SpreadsheetApp.getActiveSpreadsheet(), sheet=ss.getActiveSheet(), ui=SpreadsheetApp.getUi();
  digestRows_(sheet);
  const reply=ui.prompt('Weekly Divo email','Enter SUBSCRIBERS to use the DigestRecipients tab, or enter one email address. Delivery is Monday morning around 9 AM India time.',ui.ButtonSet.OK_CANCEL);
  if (reply.getSelectedButton()!==ui.Button.OK) return;
  const address=reply.getResponseText().trim();
  if (address!=='SUBSCRIBERS' && !/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(address)) throw Error('Enter one valid email address.');
  const lock=LockService.getUserLock();lock.waitLock(10000);
  try {
    const triggers=ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='deliverDigest_');
    if (!triggers.length) ScriptApp.newTrigger('deliverDigest_').timeBased().everyWeeks(1)
      .onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(9).inTimezone(DIGEST_ZONE).create();
    PropertiesService.getUserProperties().setProperties({digestAddress:address,digestBook:ss.getId(),digestTab:String(sheet.getSheetId())});
  } finally {lock.releaseLock();}
  ui.alert('Weekly email enabled for '+address+'.');
}

function stopDigest_() {
  const lock=LockService.getUserLock();lock.waitLock(10000);
  try {
    PropertiesService.getUserProperties().deleteProperty('digestAddress');
    ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='deliverDigest_').forEach(t=>ScriptApp.deleteTrigger(t));
  } finally {lock.releaseLock();}
  SpreadsheetApp.getUi().alert('Your weekly delivery is off.');
}

function deliverDigest_() {
  const lock=LockService.getUserLock();lock.waitLock(10000);
  try {
    const props=PropertiesService.getUserProperties(), address=props.getProperty('digestAddress'), start=digestToday_();
    if (!address || props.getProperty('digestLastSent')===start) return;
    const sheet=SpreadsheetApp.openById(props.getProperty('digestBook')).getSheets()
      .find(s=>String(s.getSheetId())===props.getProperty('digestTab'));
    const digest=buildDigest_(digestRows_(sheet),start);
    let recipients=[address];
    if(address==='SUBSCRIBERS'){
      const tab=sheet.getParent().getSheetByName('DigestRecipients');
      if(!tab)throw Error('Import the recipients CSV into a tab named DigestRecipients.');
      const [header,...rows]=tab.getDataRange().getDisplayValues();
      if(header[0]!=='email')throw Error('Expected email in cell A1.');
      recipients=[...new Set(rows.map(row=>row[0].trim().toLowerCase()).filter(Boolean))];
      if(recipients.some(email=>!/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(email)))throw Error('Check recipient addresses.');
    }
    const previous=props.getProperty('digestProgressDay');
    if(previous!==start){props.setProperty('digestProgressDay',start);props.deleteProperty('digestProgress');}
    const sent=new Set(JSON.parse(props.getProperty('digestProgress')||'[]'));
    const pending=recipients.filter(email=>!sent.has(email));
    if(MailApp.getRemainingDailyQuota()<pending.length)throw Error('Insufficient remaining daily email quota.');
    for(const email of pending){
      MailApp.sendEmail({to:email,subject:digest.subject,body:digest.body,name:'Divo Music Calendar'});
      sent.add(email);props.setProperty('digestProgress',JSON.stringify([...sent]));
    }
    props.setProperty('digestLastSent',start);
  } finally {lock.releaseLock();}
}
