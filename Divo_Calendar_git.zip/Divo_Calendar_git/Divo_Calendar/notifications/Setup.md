# Weekly Gmail digest

1. Open a Google Sheet with the Google account that should send the digest. Choose File → Import → Upload and select data/Divo_Import.csv. Choose Insert new sheet(s). If the deployed Divo calendar already has an Events tab in Sheets, use that tab directly.
2. In that spreadsheet choose Extensions → Apps Script. In a new script file paste the entire contents of WeeklyDigest.gs and save. If the project already has an onOpen function, combine its menu creation with the onOpen function in this file.
3. Reload the spreadsheet and select the tab containing the events. Choose Divo notifications → Preview next 7 days to check the events without sending email.
4. From that same tab choose Divo notifications → Enable weekly email. Authorize Google when prompted and enter one address, either your own inbox or the team's mailing list. Run the menu action again if authorization interrupts it.
5. Google schedules delivery for Mondays during the 9 AM hour in India. Each email covers Monday through Sunday. It uses the original release year to calculate anniversaries. Stop it under Divo notifications → Stop weekly email from the same Google account.

Changes to the selected Sheet tab appear in subsequent digests. If you edit the CSV in VS Code, import the updated CSV into the same tab using Replace current sheet, or enable the digest again on the new tab. Local calendar accounts and private notes are separate from this email setting. To change the address, run Enable weekly email again. Use one sender account per team mailing list to avoid duplicate deliveries.

## Send to signed-up calendar users

New accounts supply an email, and existing users without one are prompted on their next password sign-in. Users choose whether to receive the digest and can change it under Email settings. In local Admin → Weekly Gmail notifications choose Export weekly recipients. Import DigestRecipients.csv into a Google Sheet tab named exactly DigestRecipients (email in A1). Then switch back to the events tab, choose Enable weekly email and enter SUBSCRIBERS as the destination. Each listed address receives an individual copy. Refresh the recipient tab by replacing its contents after sign-ups, email changes or opt-outs and before each weekly delivery. A header-only export means nobody is subscribed. Keep the recipient sheet restricted to the sender/team admins.
