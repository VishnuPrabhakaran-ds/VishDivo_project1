"""Serve the Divo calendar and its local catalogue editor."""
import accounts
import csv
from datetime import date
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import tempfile
import threading
import webbrowser

ROOT = Path(__file__).resolve().parent
CATALOGUE = ROOT / 'data' / 'Divo_Import.csv'
FIELDS = 'type title artist language date wikiTitle tmdbId imdbId imageOverride syncDate roles'.split()
LOCK = threading.Lock()


def admin_key():
    folder = Path.home() / '.divo-calendar'
    folder.mkdir(mode=0o700, exist_ok=True)
    path = folder / 'admin-key.txt'
    if not path.exists():
        with tempfile.NamedTemporaryFile(dir=folder, delete=False) as temp:
            temp.write(secrets.token_urlsafe(24).encode('ascii'))
            prepared = Path(temp.name)
        try:
            os.link(prepared, path)
        except FileExistsError:
            pass
        finally:
            prepared.unlink()
    key = path.read_text(encoding='utf-8-sig').strip()
    if not key or not key.isascii() or not key.isprintable():
        raise SystemExit(f'Enter a key on one line in {path} and restart.')
    return key


def identity(row):
    return tuple(row[field].strip().casefold() for field in ('type', 'title', 'language'))


def revision(row):
    return hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()


def catalogue():
    if not CATALOGUE.exists():
        return FIELDS, []
    with CATALOGUE.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        if not set(FIELDS).issubset(reader.fieldnames or []):
            raise ValueError('The project CSV is missing required columns.')
        return reader.fieldnames, list(reader)


class Conflict(ValueError):
    pass


def save_event(payload):
    fields, rows = catalogue()
    original = payload.get('original')
    changes = payload.get('event')
    if not isinstance(changes, dict):
        raise ValueError('Missing event.')
    updates = {k: str(changes.get(k, '')).strip() for k in
               ('type', 'title', 'artist', 'language', 'date', 'roles')}
    if updates['type'] not in ('film', 'birth', 'music') or not updates['title']:
        raise ValueError('Choose an event type and enter a title.')
    if updates['language'] not in ('Tamil', 'Telugu', 'Malayalam', 'Kannada'):
        raise ValueError('Choose a supported language.')
    if date.fromisoformat(updates['date']).isoformat() != updates['date']:
        raise ValueError('Enter a date in YYYY-MM-DD format.')
    index = None
    if original:
        index = next((i for i, row in enumerate(rows) if revision(row) == original), None)
        if index is None:
            raise Conflict('This event changed. Reload the catalogue and select it again.')
    if any(i != index and identity(row) == identity(updates) for i, row in enumerate(rows)):
        raise Conflict('An event with this type, title and language already exists.')
    if index is None:
        rows.append(dict(updates, syncDate='false'))
    else:
        rows[index].update(updates)
    CATALOGUE.parent.mkdir(exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=CATALOGUE.parent, delete=False) as temp:
        name = Path(temp.name)
    try:
        with name.open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
        os.replace(name, CATALOGUE)
    finally:
        name.unlink(missing_ok=True)


class Handler(SimpleHTTPRequestHandler):
    def send_head(self):
        path = Path(self.translate_path(self.path)).resolve()
        if path.is_dir():
            path = path / 'index.html'
            if not path.is_file():
                self.send_error(404)
                return None
        if path in (ROOT / 'index.html', ROOT / 'notes.html', ROOT / 'preferences.html') or CATALOGUE.parent in path.parents:
            if not accounts.signed_in(self):
                self.send_response(303)
                self.send_header('Location','/login.html')
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                return None
        return super().send_head()

    def end_headers(self):
        if self.command in ('GET','HEAD'):
            self.send_header('Cache-Control','no-store')
        super().end_headers()

    def reply(self, status, result, cookie=None):
        body = json.dumps(result).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authorized(self):
        header = self.headers.get('Authorization', '')
        if secrets.compare_digest(header.encode(), ('Bearer ' + self.server.admin_key).encode()):
            return True
        self.reply(403, {'error': 'Enter the admin key printed in your VS Code terminal.'})
        return False

    def do_GET(self):
        if self.path == '/api/subscribers':
            if self.authorized():
                with accounts.database() as db:
                    emails = [row[0] for row in db.execute('SELECT min(email) FROM contacts WHERE weekly=1 GROUP BY lower(email) ORDER BY lower(email)')]
                self.reply(200, emails)
            return
        if self.path in ('/api/me','/api/notes'):
            return accounts.handle(self, self.path.rsplit('/',1)[1])
        if self.path != '/api/events':
            return super().do_GET()
        if self.authorized():
            try:
                with LOCK:
                    _, rows = catalogue()
                self.reply(200, [dict(row, revision=revision(row)) for row in rows])
            except (ValueError, OSError, csv.Error) as error:
                self.reply(400, {'error': str(error)})

    def do_POST(self):
        if self.path in ('/api/register','/api/login','/api/logout','/api/notes','/api/delete-note','/api/preferences'):
            origin = self.headers.get('Origin')
            if origin and origin != f'http://127.0.0.1:{self.server.server_port}' and origin != f'http://localhost:{self.server.server_port}':
                return self.reply(403, {'error':'Open the calendar at its local address.'})
            try:
                length = int(self.headers.get('Content-Length','0'))
                if self.headers.get_content_type() != 'application/json' or not 0 < length <= 65536:
                    raise ValueError()
                payload = json.loads(self.rfile.read(length))
                if not isinstance(payload,dict):
                    raise ValueError()
            except ValueError:
                return self.reply(400, {'error':'Invalid request.'})
            return accounts.handle(self,self.path.rsplit('/',1)[1],payload)
        if self.path != '/api/events':
            return self.send_error(404)
        if not self.authorized():
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 65536:
                raise ValueError('Invalid event size.')
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                raise ValueError('Invalid event.')
            with LOCK:
                save_event(payload)
            self.reply(200, {'saved': True})
        except Conflict as error:
            self.reply(409, {'error': str(error)})
        except (ValueError, OSError, csv.Error) as error:
            self.reply(400, {'error': str(error)})


def main():
    accounts.setup()
    key = admin_key()
    handler = partial(Handler, directory=str(ROOT))
    try:
        server = ThreadingHTTPServer(('127.0.0.1', 8765), handler)
    except OSError:
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    with server:
        server.admin_key = key
        url = f'http://127.0.0.1:{server.server_port}/'
        print(f'Calendar: {url}\nAdmin key: {key}\nPress Ctrl+C to stop.', flush=True)
        webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
