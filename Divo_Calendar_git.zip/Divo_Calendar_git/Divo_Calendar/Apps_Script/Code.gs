const COLUMNS = ['id','type','title','artist','language','date','wikiTitle','tmdbId','imdbId',
  'imageOverride','syncDate','syncedDate','wikiImage','wikiUrl','imageCredit','imageInfo',
  'tmdbImage','resolvedImdbId','resolvedTmdbId','lastChecked','syncStatus','roles','wikidataDate','wikidataUrl'];
const INPUT_COLUMNS = [...COLUMNS.slice(0,11),'roles'];
const WATCHLIST_COLUMNS = INPUT_COLUMNS.filter(key => key!=='id');
const TYPES = ['birth','music','film'];
const LANGUAGES = ['Tamil','Telugu','Malayalam','Kannada'];
const PROP = () => PropertiesService.getScriptProperties();

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index').setTitle('Divo Music Calendar')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function setup_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Bind this Apps Script project to the destination Google Sheet.');
  PROP().setProperty('SHEET_ID', ss.getId());
  withLock_(() => {
    const sheet = ss.getSheetByName('Events') || ss.insertSheet('Events');
    if (!sheet.getLastRow()) {
      sheet.appendRow(COLUMNS);
      sheet.setFrozenRows(1);
    }
    const extension = sheet.getRange(1,22,1,3);
    const headers = extension.getDisplayValues()[0];
    if (headers.every(value => !value)) extension.setValues([COLUMNS.slice(21)]);
    checkHeaders_(sheet);
  });

}

function checkHeaders_(sheet) {
  const headers = sheet.getRange(1,1,1,COLUMNS.length).getDisplayValues()[0];
  if (COLUMNS.some((column,index) => headers[index] !== column)) {
    throw new Error('Events headers do not match. Use a new sheet or migrate the rows first.');
  }
}

function sheet_() {
  const id = PROP().getProperty('SHEET_ID');
  if (!id) throw new Error('Run setup_ before opening the calendar.');
  const sheet = SpreadsheetApp.openById(id).getSheetByName('Events');
  if (!sheet) throw new Error('Events tab is missing.');
  checkHeaders_(sheet);
  return sheet;
}

function rows_(sheet) {
  const count = sheet.getLastRow() - 1;
  if (count < 1) return [];
  return sheet.getRange(2,1,count,COLUMNS.length).getValues().map((values,index) => ({
    row: index + 2,
    data: Object.fromEntries(COLUMNS.map((key,i) => [key, values[i] instanceof Date
      ? Utilities.formatDate(values[i], sheet.getParent().getSpreadsheetTimeZone(), 'yyyy-MM-dd')
      : String(values[i] ?? '')]))
  })).filter(entry => entry.data.id);
}

function withLock_(work) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try { return work(); } finally { lock.releaseLock(); }
}

function isAdmin_() {
  const email = Session.getActiveUser().getEmail().trim().toLowerCase();
  const list = (PROP().getProperty('ADMIN_EMAILS') || '').toLowerCase().split(',').map(s => s.trim());
  return Boolean(email && list.includes(email));
}

function requireAdmin_() {
  if (!isAdmin_()) throw new Error('Admin access required.');
}

function loadCalendar() {
  const admin = isAdmin_();
  const rows = rows_(sheet_()).map(entry => entry.data);
  const events = rows.filter(row => TYPES.includes(row.type) && validDate_(eventDate_(row))).map(row => {
    const imdb = row.imdbId || row.resolvedImdbId;
    const date = eventDate_(row);
    const tmdb = row.tmdbId || row.resolvedTmdbId;
    return {type:row.type,title:row.title,artist:row.artist,language:row.language,date,roles:row.roles,wikidataUrl:row.wikidataDate?row.wikidataUrl:'',
      image:row.imageOverride || row.wikiImage || row.tmdbImage,
      imageSource:row.imageOverride?'':row.wikiImage?'Wikimedia':row.tmdbImage?'TMDB':'',
      imageCredit:row.imageOverride?'':row.imageCredit,imageInfo:row.imageOverride?'':row.imageInfo,
      wikiUrl:row.wikiUrl || (row.wikiTitle ? 'https://en.wikipedia.org/wiki/'+encodeURIComponent(row.wikiTitle.replace(/ /g,'_')) : ''),tmdbUrl:tmdb && row.type!=='music'
        ? 'https://www.themoviedb.org/' + (row.type==='birth'?'person/':'movie/') + tmdb : '',
      imdbUrl:/^(tt|nm)\d+$/.test(imdb)
        ? 'https://www.imdb.com/' + (imdb.startsWith('nm')?'name/':'title/') + imdb + '/' : ''};
  });
  return {admin,events,tmdbLogo:PROP().getProperty('TMDB_LOGO_URL') || ''};
}

function listAdminEvents() {
  requireAdmin_();
  return rows_(sheet_()).map(entry => entry.data);
}

function hasTmdb_(row) {
  return row.type!=='music' && Boolean(row.tmdbId || row.imdbId);
}

function validDate_(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(value+'T00:00:00Z');
  return !isNaN(date) && date.toISOString().slice(0,10)===value;
}

function eventDate_(row) {
  return row.syncedDate || row.wikidataDate || row.date;
}

function validateRecord_(input) {
  const record = Object.fromEntries(INPUT_COLUMNS.map(key => [key,
    String(input[key] ?? '').trim().slice(0,1000)]));
  if (!TYPES.includes(record.type) || !LANGUAGES.includes(record.language) || !record.title ||
      !record.artist || (record.date && !validDate_(record.date))) throw new Error('Check the event details.');
  if (record.tmdbId && (!/^\d{1,12}$/.test(record.tmdbId) || record.type==='music')) {
    throw new Error('Enter a numeric TMDB person or film ID. Music releases use Wikipedia or custom artwork.');
  }
  if (record.imdbId && (!/^(tt|nm)\d{1,12}$/.test(record.imdbId) ||
      (record.type==='birth' && !record.imdbId.startsWith('nm')) ||
      (record.type==='film' && !record.imdbId.startsWith('tt')))) throw new Error('Check the IMDb ID.');
  if (record.imageOverride && !/^https:\/\/[^\s]+$/i.test(record.imageOverride)) {
    throw new Error('Image URL must start with https://.');
  }
  record.syncDate = record.syncDate==='true'?'true':'false';
  if (!record.date && !((hasTmdb_(record) || record.wikiTitle) && record.syncDate==='true')) {
    throw new Error('Enter an original date or enable date sync for a linked source.');
  }
  return record;
}

function saveAdminEvent(input) {
  requireAdmin_();
  const record = validateRecord_(input);
  return withLock_(() => {
    const sheet = sheet_();
    const existing = record.id && rows_(sheet).find(entry => entry.data.id===record.id);
    if (record.id && !existing) throw new Error('This event no longer exists.');
    record.id = existing ? existing.data.id : Utilities.getUuid();
    const changed = existing && ['type','wikiTitle','tmdbId','imdbId','syncDate'].some(key => existing.data[key]!==record[key]);
    const merged = {...(existing && !changed ? existing.data : {}),...record};
    write_(sheet,existing ? existing.row : sheet.getLastRow()+1,merged);
    return record.id;
  });
}

function watchlistKey_(row) {
  return [row.type,row.title,row.language].map(value => String(value).trim().toLowerCase()).join('|');
}

function importWatchlist(csv) {
  requireAdmin_();
  if (typeof csv!=='string' || csv.length>2000000) throw new Error('Use a CSV under 2 MB.');
  const [headers,...lines] = Utilities.parseCsv(csv.replace(/^\uFEFF/,''));
  if (!headers || headers.length!==WATCHLIST_COLUMNS.length ||
      headers.some((header,index) => header.trim()!==WATCHLIST_COLUMNS[index])) {
    throw new Error('Use the column headers in Divo_Import.csv.');
  }
  const nonempty = lines.filter(line => line.some(value => value.trim()));
  if (!nonempty.length || nonempty.length>10000) throw new Error('Import between 1 and 10,000 events per file.');
  const records = nonempty.map((line,index) => {
    try {
      if (line.length!==headers.length) throw new Error('Unexpected column count.');
      return validateRecord_(Object.fromEntries(WATCHLIST_COLUMNS.map((key,column) => [key,line[column]])));
    } catch (error) {
      throw new Error('Event '+(index+1)+': '+error.message);
    }
  });
  return withLock_(() => {
    const sheet = sheet_();
    const keys = new Set(rows_(sheet).map(entry => watchlistKey_(entry.data)));
    const pending = [];
    for (const record of records) {
      const key = watchlistKey_(record);
      if (keys.has(key)) continue;
      keys.add(key);
      pending.push(rowValues_({...record,id:Utilities.getUuid()}));
    }
    if (pending.length) {
      const start = sheet.getLastRow()+1;
      const extra = start+pending.length-1-sheet.getMaxRows();
      if (extra>0) sheet.insertRowsAfter(sheet.getMaxRows(),extra);
      sheet.getRange(start,1,pending.length,COLUMNS.length).setNumberFormat('@').setValues(pending);
    }
    return {added:pending.length,skipped:records.length-pending.length};
  });
}

function rowValues_(data) {
  return COLUMNS.map(key => {
    const value = String(data[key] ?? '');
    return /^[=+\-@]/.test(value) ? "'" + value : value;
  });
}

function write_(sheet,index,data) {
  if (index>sheet.getMaxRows()) sheet.insertRowsAfter(sheet.getMaxRows(),1);
  sheet.getRange(index,1,1,COLUMNS.length).setNumberFormat('@').setValues([rowValues_(data)]);
}

function refreshAdminEvent(id) {
  requireAdmin_();
  const entry = rows_(sheet_()).find(item => item.data.id===id);
  if (!entry) throw new Error('Event not found.');
  return refresh_(entry.data);
}

function refreshScheduled_() {
  const cutoff = new Date(Date.now() - 24*60*60*1000).toISOString();
  rows_(sheet_()).map(entry => entry.data)
    .filter(row => (row.wikiTitle || hasTmdb_(row)) && row.lastChecked < cutoff)
    .sort((a,b) => a.lastChecked.localeCompare(b.lastChecked)).slice(0,12)
    .forEach(refresh_);
}

function request_(url, headers={}) {
  const response = UrlFetchApp.fetch(url,{headers,muteHttpExceptions:true,followRedirects:false});
  const code = response.getResponseCode();
  if (code!==200) throw new Error('HTTP '+code);
  const data = JSON.parse(response.getContentText());
  if (data.error) throw new Error('API request failed');
  return data;
}

function query_(params) {
  return Object.entries(params).map(([key,value]) => key+'='+encodeURIComponent(value)).join('&');
}

function wiki_(title,type,syncDate) {
  const contact = PROP().getProperty('WIKI_CONTACT');
  if (!contact) throw new Error('Set WIKI_CONTACT');
  const headers = {'Api-User-Agent':'DivoMusicCalendar/1.0 ('+contact+')'};
  const api = 'https://en.wikipedia.org/w/api.php?';
  const data = request_(api+query_({action:'query',format:'json',formatversion:2,redirects:1,
    prop:'pageimages|info|pageprops',ppprop:'wikibase_item',inprop:'url',piprop:'name|thumbnail',pithumbsize:320,pilicense:'free',titles:title}),headers);
  const page = data.query?.pages?.[0];
  if (!page || page.missing) throw new Error('Page not found');
  const result = {wikiUrl:page.fullurl || '',wikiImage:'',imageCredit:'',imageInfo:''};
  const item = page.pageprops?.wikibase_item;
  if (syncDate && /^Q\d+$/.test(item || '')) {
    const date = wikidataDate_(item,type,headers);
    result.wikidataDate = date;
    result.wikidataUrl = date?'https://www.wikidata.org/wiki/'+item:'';
  }
  if (!page.pageimage || !page.thumbnail?.source) return result;
  const metadata = request_('https://commons.wikimedia.org/w/api.php?'+query_({action:'query',format:'json',
    formatversion:2,prop:'imageinfo',iiprop:'extmetadata|url',titles:'File:'+page.pageimage}),headers);
  const image = metadata.query?.pages?.[0]?.imageinfo?.[0];
  const info = image?.extmetadata;
  const license = info?.LicenseShortName?.value;
  if (image?.descriptionurl && /^(CC (BY(-SA)? [\d.]+|0)|Public domain)$/i.test(license || '')) {
    const credit = [info.Artist?.value,license].filter(Boolean).join(' · ').replace(/<[^>]*>/g,'').trim();
    Object.assign(result,{wikiImage:page.thumbnail.source,imageCredit:credit,imageInfo:image.descriptionurl});
  }
  return result;
}

function wikidataDate_(item,type,headers) {
  const property = type==='birth'?'P569':'P577';
  const data = request_('https://www.wikidata.org/w/api.php?'+query_({
    action:'wbgetclaims',format:'json',entity:item,property
  }),headers);
  const claims = (data.claims?.[property] || []).filter(claim => claim.rank!=='deprecated');
  const preferred = claims.filter(claim => claim.rank==='preferred');
  const candidates = preferred.length?preferred:claims;
  // Keep ambiguous release dates and year-only dates out of the calendar.
  const dates = new Set(candidates.map(claim => {
    const value = claim.mainsnak?.datavalue?.value;
    if (value?.precision!==11 || !value.calendarmodel?.endsWith('/Q1985727')) return '';
    const date = value.time?.match(/^\+(\d{4}-\d{2}-\d{2})T/)?.[1];
    return validDate_(date)?date:'';
  }));
  return dates.size===1?[...dates][0]:'';
}

function tmdb_(row) {
  const token = PROP().getProperty('TMDB_TOKEN');
  if (!token) throw new Error('Set TMDB_TOKEN');
  const kind = row.type==='birth'?'person':'movie';
  const headers = {Authorization:'Bearer '+token,Accept:'application/json'};
  const base = 'https://api.themoviedb.org/3/';
  if (row.tmdbId ? !/^\d{1,12}$/.test(row.tmdbId) : !/^(tt|nm)\d{1,12}$/.test(row.imdbId)) throw new Error("Invalid source ID");
  let id = row.tmdbId;
  if (!id) {
    const matches = request_(base+'find/'+row.imdbId+'?external_source=imdb_id',headers);
    const results = kind==='person'?matches.person_results:matches.movie_results;
    if (results?.length!==1) throw new Error('No unique TMDB match for the IMDb ID');
    id = String(results[0].id);
  }
  const data = request_(base+kind+'/'+id+'?append_to_response=external_ids',headers);
  const image = kind==='person'?data.profile_path:data.poster_path;
  const imdb = data.external_ids?.imdb_id || data.imdb_id || '';
  const date = kind==='person'?data.birthday:data.release_date;
  return {tmdbImage:typeof image==='string' && /^\/[\w.-]+$/.test(image)
      ? 'https://image.tmdb.org/t/p/w342'+image : '',
    resolvedTmdbId:id,resolvedImdbId:/^(nm|tt)\d+$/.test(imdb)?imdb:'',
    syncedDate:row.syncDate==='true' && validDate_(date)?date:''};
}

function refresh_(row) {
  const updates = {};
  const messages = [];
  const sources = [
    ['Wikipedia',row.wikiTitle,() => wiki_(row.wikiTitle,row.type,row.syncDate==='true')],
    ['TMDB',hasTmdb_(row),() => tmdb_(row)]
  ];
  for (const [name,configured,fetch] of sources) {
    if (!configured) continue;
    try { Object.assign(updates,fetch()); messages.push(name+' refreshed'); }
    catch (error) { messages.push(name+': '+error.message); }
  }
  if (row.syncDate==='true' && !eventDate_({...row,...updates})) {
    messages.push('Date pending: enter a source-verified date if no exact date is available');
  }
  const syncStatus = messages.join(' · ') || 'Add a Wikipedia title, TMDB ID or supported IMDb ID to refresh.';
  return withLock_(() => {
    const sheet = sheet_();
    const entry = rows_(sheet).find(item => item.data.id===row.id);
    if (!entry || ['wikiTitle','tmdbId','imdbId','syncDate','type','lastChecked']
        .some(key => entry.data[key]!==row[key])) return 'Event changed while refreshing. Retry.';
    write_(sheet,entry.row,{...entry.data,...updates,lastChecked:new Date().toISOString(),syncStatus});
    return syncStatus;
  });
}
