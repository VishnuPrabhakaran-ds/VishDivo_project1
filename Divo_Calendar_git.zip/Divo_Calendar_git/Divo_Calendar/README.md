# Divo Music Calendar

1. Extract the ZIP. Open the folder containing run.py in VS Code.
2. Copy your extraction output into data. The calendar reads data/Divo_Import.csv. Coverage.json, Source_Records.csv and Dates_to_review.csv can stay alongside it for reference.
3. Open run.py and choose Run Python File in Terminal, or run `python run.py` in that folder. Use the Python interpreter you used for extraction. No additional packages are required.
4. The browser opens the calendar. The record count appears next to Open calendar CSV. If the browser stays closed, open the local address printed in the terminal. Leave that terminal running. To stop, press Ctrl+C.
5. After replacing the CSV, refresh the browser. Open calendar CSV also lets you preview another export until the next refresh.

## Project files

- index.html contains the local calendar layout, filters, team focus, portraits and CSV loader.
- divo-music-logo.jpg contains the header artwork.
- extractor contains the optional extraction scripts and their own instructions. To regenerate from the project root, run `python extractor/snapshot.py --start 1990 --output data`.
- Apps_Script contains the separate Google Sheets deployment with shared admin editing. See Apps_Script_Setup.md for setup. For the local presentation, run.py is sufficient.

The launcher serves the project on your own computer. To demonstrate on another computer, copy the project including your data/Divo_Import.csv. Preparation status is stored per browser and local address. Portraits require an available image URL; other entries display initials.

## Local user and admin views

Start run.py. The Team dashboard opens first. Choose a period, select an event to open its calendar details, or click Open calendar. User home returns to the dashboard. Click Admin and enter the admin key printed in the VS Code terminal for this run. Search the catalogue, select an event to edit, or enter a new event. Save event writes to data/Divo_Import.csv. Choose User calendar to see the updated data. Open calendar CSV previews a different file for that session; admin edits always target the project's data/Divo_Import.csv.

The first run creates a fixed key for your computer user account and prints it on each launch. To choose your own key on Windows, open %USERPROFILE%\.divo-calendar\admin-key.txt, enter your chosen key on one line using printable ASCII characters, save and restart run.py. Sign out clears the key from the page. For a shared Workspace deployment with named admin accounts use the separate Apps_Script version and its setup guide. A later extraction targeting the same data folder regenerates the CSV; keep a copy of manually edited exports before regenerating.


## User accounts and notes

Start run.py and choose Create an account on first use. Sign in to open the Team dashboard. My notes lets each user create, edit and delete personal notes. Sign out before another user uses the same browser. The admin key and user passwords are separate. Accounts and notes are stored in users.sqlite3 under the computer user's .divo-calendar folder, outside the project and its CSV export. Privacy is enforced between app accounts. A computer owner with access to the database can read it. Moving the ZIP alone does not move the accounts or notes.

## Weekly Gmail notifications

See [weekly email setup](notifications/Setup.md) to enable Monday digests using your calendar CSV or the deployed Events sheet.
