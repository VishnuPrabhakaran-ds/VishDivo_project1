"""Build the calendar's dated South Indian catalogue from the Wikidata QLever index."""
import argparse
import csv
from collections import Counter, defaultdict
import time
from datetime import date
import json
from pathlib import Path
import re
from urllib.parse import unquote

from sparql import query

LANGUAGES = ('Tamil','Telugu','Malayalam','Kannada')
HEADERS = ('type','title','artist','language','date','wikiTitle','tmdbId','imdbId',
           'imageOverride','syncDate','roles')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--start',type=int,default=1990)
parser.add_argument('--end',type=int,default=date.today().year)
parser.add_argument('--output',type=Path,default=Path('data'))
args = parser.parse_args()
if not 1900<=args.start<=args.end<=date.today().year:
    parser.error('Use a valid release year range ending no later than this year.')
output = args.output
(output/'.cache').mkdir(parents=True,exist_ok=True)

LANG = dict(zip(('Q5885','Q8097','Q36236','Q33673'),LANGUAGES))
ROLE = dict(zip(('P57','P162','P161','P86','P175','P676'),
                ('Director','Producer','Actor','Composer','Performer','Lyricist')))
WORKS = {
    'film': '?work wdt:P364 ?lang; wdt:P31/wdt:P279* wd:Q11424.',
    'music': '''VALUES ?class {wd:Q7366 wd:Q134556 wd:Q217199 wd:Q482994 wd:Q1333477}
        ?work (wdt:P364|wdt:P407) ?lang; wdt:P31/wdt:P279* ?class.''',
}
RANGE_START = f'{args.start:04d}-01-01'
RANGE_END = min(f'{args.end:04d}-12-31',date.today().isoformat())
DATE_RANGE = f'''FILTER(?day >= "{RANGE_START}T00:00:00Z"^^xsd:dateTime &&
                          ?day <= "{RANGE_END}T00:00:00Z"^^xsd:dateTime)'''
RELEASE_DATE = '''?work p:P577 ?statement.
    ?statement psv:P577 ?value; wikibase:rank ?rank.
    FILTER(?rank != wikibase:DeprecatedRank)
    ?value wikibase:timePrecision 11; wikibase:timeCalendarModel wd:Q1985727; wikibase:timeValue ?day.'''
BIRTH_DATE = '''?person p:P569 ?birthday.
    ?birthday psv:P569 ?birthValue; wikibase:rank ?birthRank.
    FILTER(?birthRank != wikibase:DeprecatedRank)
    ?birthValue wikibase:timePrecision 11; wikibase:timeCalendarModel wd:Q1985727; wikibase:timeValue ?born.'''
LANGS = 'VALUES ?lang {' + ' '.join(f'wd:{language}' for language in LANG) + '}'
ROLES = 'VALUES ?credit {' + ' '.join(f'wdt:{role}' for role in ROLE) + '}'


def read_query(name, body):
    path = output/'.cache'/(name+f'-{RANGE_START}-{RANGE_END}.json')
    if path.exists():
        try:
            return json.loads(path.read_text(encoding='utf-8'))
        except (UnicodeError, json.JSONDecodeError):
            print(f'Redownloading unreadable cache for {name}.', flush=True)
    print(f'Requesting {name}…',flush=True)
    time.sleep(2)
    rows = [{key:value['value'] for key,value in row.items()} for row in query(body)]
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(rows,ensure_ascii=False), encoding='utf-8')
    temporary.replace(path)
    print(f'{name} downloaded: {len(rows):,} statements',flush=True)
    return rows


def get_works(kind):
    return read_query(kind,f'''SELECT DISTINCT ?work ?lang ?title ?day ?rank ?article ?imdb ?tmdb WHERE {{
       {LANGS} {WORKS[kind]} {RELEASE_DATE} {DATE_RANGE}
       ?work rdfs:label ?title. FILTER(LANG(?title)="en")
       OPTIONAL {{ ?article schema:about ?work; schema:isPartOf <https://en.wikipedia.org/>. }}
       OPTIONAL {{ ?work wdt:P345 ?imdb. }}
       OPTIONAL {{ ?work wdt:P4947 ?tmdb. }}
    }}''')


def get_credits(kind):
    return read_query(kind+'-credits',f'''SELECT DISTINCT ?work ?lang ?person ?credit ?name ?born ?birthRank ?article ?imdb ?tmdb WHERE {{
       {{ SELECT DISTINCT ?work ?lang WHERE {{ {LANGS} {WORKS[kind]} {RELEASE_DATE} {DATE_RANGE} }} }}
       {ROLES} ?work ?credit ?person. ?person wdt:P31 wd:Q5; rdfs:label ?name. FILTER(LANG(?name)="en")
       OPTIONAL {{ {BIRTH_DATE} }}
       OPTIONAL {{ ?article schema:about ?person; schema:isPartOf <https://en.wikipedia.org/>. }}
       OPTIONAL {{ ?person wdt:P345 ?imdb. }}
       OPTIONAL {{ ?person wdt:P4985 ?tmdb. }}
    }}''')


def tail(uri):
    return uri.rsplit('/',1)[-1]


def article_title(uri):
    return unquote(uri.split('/wiki/',1)[1]).replace('_',' ') if '/wiki/' in uri else ''


def exact(rows, date_key, rank_key):
    preferred = [r for r in rows if r.get(rank_key,'').endswith('PreferredRank')]
    days = {r[date_key][:10] for r in (preferred or rows) if r.get(date_key)}
    return next(iter(days)) if len(days)==1 else ''


def choose(rows,key,pattern):
    entries = {row[key] for row in rows if re.fullmatch(pattern,row.get(key,''))}
    return next(iter(entries)) if len(entries)==1 else ''


def make(kind,title,artist,lang,day,group,roles):
    article = next((r['article'] for r in group if r.get('article')),'')
    imdb = choose(group,'imdb',('nm' if kind=='birth' else 'tt')+r'\d{1,12}')
    tmdb = '' if kind=='music' else choose(group,'tmdb',r'\d{1,12}')
    return dict(zip(HEADERS,(kind,title,artist,lang,day,article_title(article),tmdb,imdb,'','false',roles)))


def main():
    try:
        works = {kind: get_works(kind) for kind in WORKS}
        credits = {kind: get_credits(kind) for kind in WORKS}
    except (OSError, RuntimeError, ValueError) as error:
        raise SystemExit(f'{error} Completed queries are cached. Rerun the same command to resume.')
    rows, source, review = {}, {}, set()
    def put(row, url):
        key = (row['type'],row['title'].casefold(),row['language'])
        rows[key] = row
        source[key] = url
    people = defaultdict(list)
    for kind,release_rows in works.items():
        groups = defaultdict(list)
        associated = defaultdict(list)
        for row in release_rows:
            groups[(row['work'],row['lang'])].append(row)
        for row in credits[kind]:
            associated[(row['work'],row['lang'])].append(row)
        for (work,language_uri),group in sorted(groups.items()):
            language = LANG[tail(language_uri)]
            title = group[0]['title']
            day = exact(group,'day','rank')
            if not day:
                review.add((kind,title,language,work,'Conflicting release dates'))
                continue
            members = associated[(work,language_uri)]
            named = defaultdict(set)
            for credit in members:
                role = ROLE[tail(credit['credit'])]
                named[role].add(credit['name'])
                people[(credit['person'],language)].append(credit)
            featured = []
            for role in ('Director','Producer','Composer','Performer','Lyricist','Actor'):
                featured.extend(sorted(named[role])[:3])
            credits_text = ' · '.join(dict.fromkeys(featured))[:900] or 'Credits pending'
            put(make(kind,title,credits_text,language,day,group,
                     'Film release' if kind=='film' else 'Music release'),work)
    for (person,language),group in sorted(people.items()):
        title = group[0]['name']
        day = exact(group,'born','birthRank')
        if day and not ('1850-01-01'<=day<=RANGE_END):
            continue
        if not day:
            if any(credit.get('born') for credit in group):
                review.add(('birth',title,language,person,'Conflicting birth dates'))
            continue
        roles = ' · '.join(sorted({ROLE[tail(credit['credit'])] for credit in group}))
        put(make('birth',title,title,language,day,group,roles),person)
    seed = Path(__file__).with_name('Divo_Watchlist.csv')
    with seed.open(encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            if row['type']=='birth' or RANGE_START<=row['date']<=RANGE_END:
                put(row,'')
    result = sorted(rows.values(),key=lambda r:(r['type'],r['date'],r['title'],r['language']))
    with (output/'Divo_Import.csv').open('w',newline='',encoding='utf-8') as f:
        writer = csv.DictWriter(f,fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(result)
    with (output/'Source_Records.csv').open('w',newline='',encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['type','title','language','wikidata_url','wikipedia_title'])
        for row in result:
            writer.writerow([row['type'],row['title'],row['language'],
                             source[(row['type'],row['title'].casefold(),row['language'])],row['wikiTitle']])
    with (output/'Dates_to_review.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f)
        writer.writerow(['type','title','language','wikidata_url','reason'])
        writer.writerows(sorted(review))
    summary=dict(start=args.start,end=args.end,cutoff=RANGE_END,
                 records=dict(Counter(row['type'] for row in result)),
                 languages=dict(Counter(row['language'] for row in result)),
                 review_candidates=len(review),failed_requests=[])
    (output/'Coverage.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    main()
