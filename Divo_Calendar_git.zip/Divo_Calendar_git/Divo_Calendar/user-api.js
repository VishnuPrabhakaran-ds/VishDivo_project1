async function userRequest(action, data) {
 const options={cache:'no-store'};
 if(data!==undefined) Object.assign(options,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
 const response=await fetch('/api/'+action,options);
 if(response.status===401 && !location.pathname.endsWith('/login.html')){
  location.replace('login.html');
  throw Error('Please sign in.');
 }
 const result=await response.json();
 if(!response.ok){const error=Error(result.error||'Request failed.');error.status=response.status;throw error;}
 return result;
}
async function signOut(){
 try{await userRequest('logout',{});location.replace('login.html');}
 catch(error){alert(error.message);}
}
window.addEventListener('pageshow',e=>{if(e.persisted) location.reload();});
