"""Local calendar accounts and private notes, stored outside the web directory."""
from contextlib import contextmanager
import hashlib
from http.cookies import SimpleCookie, CookieError
import re
import secrets
import sqlite3
from pathlib import Path
import time

STORE = Path.home() / '.divo-calendar' / 'users.sqlite3'
LIFETIME = 7 * 86400


@contextmanager
def database():
    STORE.parent.mkdir(mode=0o700, exist_ok=True)
    connection = sqlite3.connect(STORE, timeout=10)
    try:
        with connection:
            yield connection
    finally:
        connection.close()


def setup():
    with database() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY, username TEXT UNIQUE, salt BLOB, password BLOB);
            CREATE TABLE IF NOT EXISTS contacts (user_id INTEGER PRIMARY KEY, email TEXT NOT NULL, weekly INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY, user_id INTEGER, expires INTEGER);
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY, user_id INTEGER, body TEXT, updated INTEGER);
            CREATE INDEX IF NOT EXISTS note_owner ON notes(user_id);
        """)


def contact_values(payload):
    email = payload.get('email', '')
    if not isinstance(email, str):
        raise ValueError('Enter your email address.')
    email = email.strip()
    if len(email)>254 or not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9._%+'-]*@[a-zA-Z0-9.-]+[.][a-zA-Z]{2,}", email):
        raise ValueError('Enter a valid email address.')
    return email, int(payload.get('weekly') is True)


def digest(password, salt):
    return hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1)


def cookie_token(handler):
    cookie = SimpleCookie()
    try:
        cookie.load(handler.headers.get('Cookie', ''))
    except CookieError:
        return ''
    token = cookie.get('divo_session')
    return hashlib.sha256(token.value.encode()).hexdigest() if token else ''


def signed_in(handler):
    with database() as db:
        return db.execute('SELECT 1 FROM sessions WHERE token=? AND expires>?',
                          (cookie_token(handler),time.time())).fetchone() is not None


def handle(handler, action, payload=None):
    cookie = None
    with database() as db:
        token = cookie_token(handler)
        user = db.execute("""SELECT users.id, username FROM users JOIN sessions
            ON users.id=sessions.user_id WHERE token=? AND expires>?""",
            (token, time.time())).fetchone()
        if action in ('register', 'login'):
            username = str(payload.get('username', '')).strip().casefold()
            password = payload.get('password')
            if not username or len(username)>80 or not isinstance(password,str) or len(password)>256:
                return handler.reply(400, {'error':'Enter a username and password.'})
            if action == 'register':
                try:
                    contact = contact_values(payload)
                except ValueError as error:
                    return handler.reply(400, {'error':str(error)})
                if len(password)<10:
                    return handler.reply(400, {'error':'Use a password of at least 10 characters.'})
                salt = secrets.token_bytes(16)
                try:
                    cursor = db.execute('INSERT INTO users(username,salt,password) VALUES(?,?,?)',
                                        (username,salt,digest(password,salt)))
                except sqlite3.IntegrityError:
                    return handler.reply(409, {'error':'That username is already taken.'})
                uid = cursor.lastrowid
                db.execute('INSERT INTO contacts VALUES(?,?,?)',(uid,*contact))
            else:
                record = db.execute('SELECT id,salt,password FROM users WHERE username=?',(username,)).fetchone()
                check = digest(password, record[1] if record else bytes(16))
                if not record or not secrets.compare_digest(check,record[2]):
                    return handler.reply(401, {'error':'Check your username and password.'})
                uid = record[0]
                if not db.execute('SELECT 1 FROM contacts WHERE user_id=?',(uid,)).fetchone():
                    if not payload.get('email'):
                        return handler.reply(428, {'error':'Add your email to finish signing in.'})
                    try:
                        contact = contact_values(payload)
                    except ValueError as error:
                        return handler.reply(400, {'error':str(error)})
                    db.execute('INSERT INTO contacts VALUES(?,?,?)',(uid,*contact))
            raw = secrets.token_urlsafe(32)
            db.execute('DELETE FROM sessions WHERE token=? OR expires<=?',(token,time.time()))
            db.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(raw.encode()).hexdigest(),uid,int(time.time())+LIFETIME))
            cookie = f'divo_session={raw}; Path=/; HttpOnly; SameSite=Strict; Max-Age={LIFETIME}'
            result = {'username':username}
        elif action == 'logout':
            db.execute('DELETE FROM sessions WHERE token=?',(token,))
            cookie = 'divo_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'
            result = {'signedOut':True}
        elif not user:
            return handler.reply(401, {'error':'Sign in to your calendar account.'})
        elif action == 'preferences':
            try:
                contact = contact_values(payload)
            except ValueError as error:
                return handler.reply(400, {'error':str(error)})
            db.execute('INSERT OR REPLACE INTO contacts VALUES(?,?,?)',(user[0],*contact))
            result = {'saved':True}
        elif action == 'me':
            contact = db.execute('SELECT email,weekly FROM contacts WHERE user_id=?',(user[0],)).fetchone()
            result = {'username':user[1],'email':contact[0] if contact else '', 'weekly':bool(contact and contact[1])}
        elif action == 'notes' and payload is None:
            result = [dict(id=i,body=b,updated=t) for i,b,t in db.execute(
                'SELECT id,body,updated FROM notes WHERE user_id=? ORDER BY updated DESC,id DESC',(user[0],))]
        elif action == 'notes':
            body = payload.get('body')
            if not isinstance(body,str) or not 1<=len(body.strip())<=5000:
                return handler.reply(400, {'error':'Enter a note of up to 5,000 characters.'})
            if payload.get('id') is None:
                db.execute('INSERT INTO notes(user_id,body,updated) VALUES(?,?,?)',(user[0],body.strip(),int(time.time())))
            elif type(payload['id']) is not int or not db.execute(
                    'UPDATE notes SET body=?,updated=? WHERE id=? AND user_id=?',
                    (body.strip(),int(time.time()),payload['id'],user[0])).rowcount:
                return handler.reply(404, {'error':'Note unavailable.'})
            result = {'saved':True}
        elif action == 'delete-note':
            note_id = payload.get('id')
            if type(note_id) is not int or not db.execute('DELETE FROM notes WHERE id=? AND user_id=?',(note_id,user[0])).rowcount:
                return handler.reply(404, {'error':'Note unavailable.'})
            result = {'deleted':True}
    handler.reply(200,result,cookie)
